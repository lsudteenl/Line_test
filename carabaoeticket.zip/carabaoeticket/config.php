<?php
// Line Access token
$line_AccessToken = "d0jyEwZYG7bHT6J2jSVaOcdN3gxEesdbq1pkDdNvH/vltEVfS8v0K/9wC3bGOPXtHq+KzS1nDWnJVAgpE2eH7m9i0bIKr8c6d1YUwukypR93vKSEFwZEVCfWgKkfPN3KC50OCriXb2vVMzs4a6ZbHwdB04t89/1O/w1cDnyilFU="; //Line Developer Token
$GLOBALS['linenotify_token'] = array("spHphqn5t4I9T5G11Dt9Pb9Q9YRsxmULNM96YKDrRwE"); //สามารถ Gen ได้จาก https://notify-bot.line.me/my/ 1 Token ต่อ 1 กลุ่ม

//Data Base
$dbhost = "localhost";
$dbname = "opdevmen_eticket";
$dbusername = "opdevmen_eticket";
$dbpassword = "line#eticket";

// Mail
$to = 'koopybz@gmail.com';
$from = 'support@opdev.men';
$from_name = 'OPDEV Support Team';


// อย่าลืมตั้ง 777 ให้กับโฟลเดอร์ content ไม่งั้นจะลบไฟล์ไม่ได้

?>